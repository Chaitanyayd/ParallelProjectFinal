package com.cg.exception;

public class InvalidInputException extends RuntimeException {

	public InvalidInputException(String message) {
		super(message);
		
	}
	
	

}
